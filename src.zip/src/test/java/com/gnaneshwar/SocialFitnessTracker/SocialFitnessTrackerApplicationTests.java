package com.gnaneshwar.SocialFitnessTracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SocialFitnessTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
