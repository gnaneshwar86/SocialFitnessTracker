package com.gnaneshwar.SocialFitnessTracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SocialFitnessTrackerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SocialFitnessTrackerApplication.class, args);
	}

}
