package com.gnaneshwar.SocialFitnessTracker.enums;

public enum GoalType {
    STEPS, CALORIES, DISTANCE, WORKOUTS
}
