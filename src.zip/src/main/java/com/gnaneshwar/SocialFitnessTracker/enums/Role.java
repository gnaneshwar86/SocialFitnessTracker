package com.gnaneshwar.SocialFitnessTracker.enums;

public enum Role {
    USER, ADMIN
}
