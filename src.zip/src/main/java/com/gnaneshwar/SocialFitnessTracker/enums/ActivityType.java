package com.gnaneshwar.SocialFitnessTracker.enums;

public enum ActivityType {
    WALKING, RUNNING, CYCLING, SWIMMING
}
